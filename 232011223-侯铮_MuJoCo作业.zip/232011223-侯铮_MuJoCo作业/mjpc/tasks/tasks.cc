#include "mjpc/tasks/tasks.h"
#include "mjpc/tasks/simple_car/simple_car.h" // 引入 Simple Car 头文件

namespace mjpc {

std::vector<std::shared_ptr<Task>> GetTasks() {
  // 返回只包含 Simple Car 的列表
  return {
    std::make_shared<SimpleCar>(),
  };
}

}  // namespace mjpc
