# Simple Car Task

A simple navigation task for a differential-drive car in MuJoCo MPC.

## Description

This task demonstrates a basic car navigation controller where a simple car with two rear wheels and a front caster wheel must navigate to a goal position (x, y).

## Model

The car model (`car_model.xml`) features:
- **Chassis**: A custom mesh representing the car body with explicit inertial properties
- **Wheels**: Two rear wheels controlled independently via tendons
- **Front caster**: A sphere providing forward support
- **Actuators**: Two motors for forward/backward motion and turning
  - `forward`: Controls average speed of both wheels (gear=5)
  - `turn`: Controls differential speed for steering (gear=3)
- **Physics**: 
  - Newton solver with 50 iterations for numerical stability
  - 2ms timestep
  - Enhanced friction (1.5 for wheels, 1.0 for ground)
  - Joint damping (0.1) and armature (0.01) for stability

## Task Definition

The task is defined in `simple_car.cc` with the following residuals:

### Residuals (4 total)
1. **Position X** (residual 0): Distance from goal x-coordinate
2. **Position Y** (residual 1): Distance from goal y-coordinate  
3. **Control Forward** (residual 2): Forward motor control effort
4. **Control Turn** (residual 3): Turn motor control effort

### Cost Function

The cost function penalizes:
- Distance to goal position (x, y)
- Control effort for both actuators

### Parameters

Goal position can be configured via XML:
- `residual_Goal_Position_x`: Target x-coordinate (default: 1.0, range: 0.0-3.0)
- `residual_Goal_Position_y`: Target y-coordinate (default: 1.0, range: 0.0-3.0)

## Running the Task

```bash
./build/bin/mjpc --task SimpleCar
```

## Files

- `car_model.xml`: MuJoCo model definition for the car
- `task.xml`: Task configuration including cost weights and parameters
- `simple_car.h`: Task header file
- `simple_car.cc`: Task implementation with residual function
