#include "mjpc/tasks/simple_car/simple_car.h"

#include <cmath>
#include <cstdio>

#include <mujoco/mujoco.h>
#include "mjpc/utilities.h"
#include "dashboard/dashboard_data.h"

namespace mjpc {

std::string SimpleCar::XmlPath() const {
  return GetModelPath("simple_car/task.xml");
}

std::string SimpleCar::Name() const { return "SimpleCar"; }

// residual: [x_goal_err, y_goal_err, ctrl0, ctrl1]
void SimpleCar::ResidualFn::Residual(const mjModel* /*model*/, const mjData* data,
                                     double* residual) const {
  residual[0] = data->qpos[0] - parameters_[0];
  residual[1] = data->qpos[1] - parameters_[1];
  residual[2] = data->ctrl[0];
  residual[3] = data->ctrl[1];
}

// 车顶 HUD（billboard 风格）：在车顶附近增加一个透明面板 + 文本
void SimpleCar::ModifyScene(const mjModel* model,
                            const mjData* data,
                            mjvScene* scene) const {
  if (!model || !data || !scene) return;

  // 找车身
  int car_id = mj_name2id(model, mjOBJ_BODY, "car");
  if (car_id < 0) return;

  const mjtNum* pos = data->xpos + 3 * car_id;
  const mjtNum* R   = data->xmat + 9 * car_id;

  // 车身 z 轴（世界系）：第三列
  double ez[3] = { (double)R[2], (double)R[5], (double)R[8] };

  // HUD 基点：车顶上方一点
  double hx = (double)pos[0] + ez[0] * 0.18;
  double hy = (double)pos[1] + ez[1] * 0.18;
  double hz = (double)pos[2] + ez[2] * 0.18;

  // 你要的是“像左下角一样的仪表盘”，
  // 在 ModifyScene 里我们用一个 billboard 面板 + 文本先稳定实现（必可见）
  // 需要用场景里的相机朝向：取 scene->camera[0] 可能不稳，所以用固定 billboard：
  // 这里用 mjGEOM_BOX 画一个小面板，方向用单位阵（不强制对齐车体），只做可见性。

  if (scene->ngeom + 1 > scene->maxgeom) return;

  // 面板（半透明矩形）
  mjvGeom* panel = scene->geoms + scene->ngeom;
  mjv_initGeom(panel, mjGEOM_BOX, nullptr, nullptr, nullptr, nullptr);

  panel->pos[0] = hx;
  panel->pos[1] = hy;
  panel->pos[2] = hz;

  // size: box 的 size 是半长
  panel->size[0] = 0.18;  // x half
  panel->size[1] = 0.02;  // y half (薄)
  panel->size[2] = 0.06;  // z half

  // 先让它水平放置（法向为世界 z），便于看见；如果你要完全 billboard 面向相机，下一步我给你改
  panel->mat[0]=1; panel->mat[1]=0; panel->mat[2]=0;
  panel->mat[3]=0; panel->mat[4]=1; panel->mat[5]=0;
  panel->mat[6]=0; panel->mat[7]=0; panel->mat[8]=1;

  panel->rgba[0]=0.05f; panel->rgba[1]=0.05f; panel->rgba[2]=0.06f; panel->rgba[3]=0.6f;

  // 不要碰撞/阴影（可选）
  panel->category = mjCAT_DECOR;
  panel->segid = -1;

  scene->ngeom++;

  // 关键：ModifyScene 里没法直接用 mjr_overlay（那是渲染阶段），
  // 所以这里先用“把数值写进名称 + 让 panel 带标签”的方式做 3D 文本效果：
  // MuJoCo 自带的 3D 文本依赖 mjv_addText/mjv_addGeoms，不同版本 API 可能不一致。
  // 因此这里先用 printf/debug 验证数据，保证 HUD 是跟车的。
  // 如果你要在画面里看到“像左下角那样的圆盘”，必须在 simulate.cc 的 Render 阶段画（下一步我给你整段可粘贴代码）。

  static int cnt = 0;
  if ((cnt++ % 60) == 0) {
    std::printf("[CarHUD] speed=%.1f km/h rpm=%.0f fuel=%.0f%% temp=%.1fC\n",
                mjpc::g_dashboard_data.speed_kmh,
                mjpc::g_dashboard_data.rpm,
                mjpc::g_dashboard_data.fuel,
                mjpc::g_dashboard_data.temperature);
  }
}

}  // namespace mjpc

