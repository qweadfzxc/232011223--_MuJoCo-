#pragma once

#include <mujoco/mujoco.h>

// 仪表盘数据
struct DashboardData {
  double speed_mps = 0.0;
  double speed_kmh = 0.0;

  double rpm = 0.0;
  double fuel = 100.0;
  double temperature = 60.0;

  double pos[3] = {0.0, 0.0, 0.0};
  double vel[3] = {0.0, 0.0, 0.0};
  double acc[3] = {0.0, 0.0, 0.0};
};

class DashboardDataExtractor {
 public:
  explicit DashboardDataExtractor(const mjModel* m, const char* car_body_name = nullptr);
  void Update(const mjModel* m, const mjData* d, DashboardData& out);

  void SetPrintEveryN(int n) { print_every_n_ = n; }
  int car_body_id() const { return car_body_id_; }

 private:
  int car_body_id_ = -1;

  double fuel_ = 100.0;
  double rpm_smooth_ = 900.0;
  double temp_smooth_ = 60.0;

  double last_vel_[3] = {0.0, 0.0, 0.0};
  bool has_last_vel_ = false;

  int print_every_n_ = 0;
  int frame_count_ = 0;
};

// 只把全局变量放进 mjpc 命名空间
namespace mjpc {
extern DashboardData g_dashboard_data;
}  // namespace mjpc

