#include "dashboard/dashboard_data.h"

#include <algorithm>
#include <cmath>
#include <cstdio>
#include "dashboard/dashboard_data.h"
namespace mjpc {
DashboardData g_dashboard_data;
}  // namespace mjpc


static constexpr const char* kDefaultCarBodyName = "car";

DashboardDataExtractor::DashboardDataExtractor(const mjModel* m, const char* car_body_name) {
  const char* name = (car_body_name && car_body_name[0]) ? car_body_name : kDefaultCarBodyName;
  car_body_id_ = mj_name2id(m, mjOBJ_BODY, name);
  if (car_body_id_ < 0) {
    std::printf("[DashboardDataExtractor] WARN: body '%s' not found, fallback to body 0\n", name);
    car_body_id_ = 0;
  } else {
    std::printf("[DashboardDataExtractor] Using car body '%s', id=%d\n", name, car_body_id_);
  }
    print_every_n_ = 60;   // 每 60 帧打印一次 dashboard 数据

}

void DashboardDataExtractor::Update(const mjModel* m, const mjData* d, DashboardData& out) {
  // --- Position (world) ---
  out.speed_kmh *= 20.0;   // 仅用于验证 UI
  out.pos[0] = d->xpos[3 * car_body_id_ + 0];
  out.pos[1] = d->xpos[3 * car_body_id_ + 1];
  out.pos[2] = d->xpos[3 * car_body_id_ + 2];

  // --- Velocity (world): use mj_objectVelocity for robustness ---
  // Convention: res[0..2] angular vel, res[3..5] linear vel
  mjtNum vel6[6] = {0};
  mj_objectVelocity(m, d, mjOBJ_BODY, car_body_id_, vel6, /*flg_local=*/0);

  out.vel[0] = static_cast<double>(vel6[3]);
  out.vel[1] = static_cast<double>(vel6[4]);
  out.vel[2] = static_cast<double>(vel6[5]);

  out.speed_mps = std::sqrt(out.vel[0] * out.vel[0] +
                            out.vel[1] * out.vel[1] +
                            out.vel[2] * out.vel[2]);
  if (!std::isfinite(out.speed_mps)) out.speed_mps = 0.0;
  out.speed_kmh = out.speed_mps * 3.6;

  // --- Acceleration (world): finite difference on linear velocity ---
  const double dt = (m->opt.timestep > 0) ? m->opt.timestep : 0.001;
  if (has_last_vel_) {
    out.acc[0] = (out.vel[0] - last_vel_[0]) / dt;
    out.acc[1] = (out.vel[1] - last_vel_[1]) / dt;
    out.acc[2] = (out.vel[2] - last_vel_[2]) / dt;
  } else {
    out.acc[0] = out.acc[1] = out.acc[2] = 0.0;
    has_last_vel_ = true;
  }
  last_vel_[0] = out.vel[0];
  last_vel_[1] = out.vel[1];
  last_vel_[2] = out.vel[2];

  // --- Simulated RPM (0-8000), smooth pointer movement ---
  // idle ~ 900 rpm; scale with speed
  double rpm_raw = 900.0 + out.speed_kmh * 35.0;
  rpm_raw = std::clamp(rpm_raw, 0.0, 8000.0);
  const double alpha = 0.15;  // smoothing factor
  rpm_smooth_ = (1.0 - alpha) * rpm_smooth_ + alpha * rpm_raw;
  out.rpm = rpm_smooth_;

  // --- Simulated fuel (%), decreases slowly ---
  fuel_ -= 0.002;  // tune as you like
  if (fuel_ < 0.0) fuel_ = 100.0;
  out.fuel = fuel_;

  // --- Simulated temperature (60-120C), smooth ---
  double temp_raw = 60.0 + (out.rpm / 8000.0) * 60.0;
  temp_smooth_ = (1.0 - alpha) * temp_smooth_ + alpha * temp_raw;
  out.temperature = temp_smooth_;

  // --- Optional debug print ---
  if (print_every_n_ > 0) {
    frame_count_++;
    if ((frame_count_ % print_every_n_) == 0) {
      std::printf("[Dash] v=%.1f km/h  rpm=%.0f  fuel=%.0f%%  temp=%.1fC  pos=(%.2f %.2f %.2f)\n",
                  out.speed_kmh, out.rpm, out.fuel, out.temperature,
                  out.pos[0], out.pos[1], out.pos[2]);
    }
  }
}

