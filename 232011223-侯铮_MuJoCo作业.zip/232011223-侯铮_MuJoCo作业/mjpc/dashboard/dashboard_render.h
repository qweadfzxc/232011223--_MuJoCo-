#pragma once

#include <mujoco/mujoco.h>
#include "dashboard/dashboard_data.h"

// OpenGL HUD 渲染（2D覆盖层）
// 用法：在 mjr_render(...) 之后调用 Render(...)
class DashboardRenderer {
 public:
  // viewport：来自 MJPC 的 mjrRect（framebuffer 尺寸）
  // ctx：可选，用于画 mjr_overlay 文字（不传也行）
  void Render(const DashboardData& data, const mjrRect& viewport, const mjrContext* ctx = nullptr);

  // 你想调整布局可改这些参数
  void SetScale(float s) { scale_ = (s > 0.f ? s : 1.f); }

 private:
  float scale_ = 1.0f;
};

