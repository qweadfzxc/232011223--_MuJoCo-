#include "dashboard/dashboard_render.h"

#include <algorithm>
#include <cmath>
#include <cstdio>

#ifdef __APPLE__
#include <OpenGL/gl.h>
#else
#include <GL/gl.h>
#endif

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

// ---------- small helpers ----------
static void Begin2D(const mjrRect& v) {
  glMatrixMode(GL_PROJECTION);
  glPushMatrix();
  glLoadIdentity();
  glOrtho(0, v.width, 0, v.height, -1, 1);

  glMatrixMode(GL_MODELVIEW);
  glPushMatrix();
  glLoadIdentity();

  glDisable(GL_DEPTH_TEST);
  glDisable(GL_LIGHTING);

  glEnable(GL_BLEND);
  glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
}

static void End2D() {
  glDisable(GL_BLEND);
  glEnable(GL_DEPTH_TEST);

  glMatrixMode(GL_MODELVIEW);
  glPopMatrix();
  glMatrixMode(GL_PROJECTION);
  glPopMatrix();
  glMatrixMode(GL_MODELVIEW);
}

static void DrawCircle(float cx, float cy, float r, int segments) {
  glBegin(GL_TRIANGLE_FAN);
  glVertex2f(cx, cy);
  for (int i = 0; i <= segments; i++) {
    float a = 2.0f * (float)M_PI * (float)i / (float)segments;
    glVertex2f(cx + r * std::cos(a), cy + r * std::sin(a));
  }
  glEnd();
}

static void DrawRing(float cx, float cy, float r1, float r2, int segments) {
  glBegin(GL_TRIANGLE_STRIP);
  for (int i = 0; i <= segments; i++) {
    float a = 2.0f * (float)M_PI * (float)i / (float)segments;
    float cs = std::cos(a), sn = std::sin(a);
    glVertex2f(cx + r2 * cs, cy + r2 * sn);
    glVertex2f(cx + r1 * cs, cy + r1 * sn);
  }
  glEnd();
}

static void DrawNeedle(float cx, float cy, float len, float angle_rad, float width) {
  glLineWidth(width);
  glBegin(GL_LINES);
  glVertex2f(cx, cy);
  glVertex2f(cx + len * std::cos(angle_rad), cy + len * std::sin(angle_rad));
  glEnd();
  glLineWidth(1.0f);
}

// angle mapping: 0 -> 225deg, max -> -45deg (sweep 270deg)
static float GaugeAngle(float value, float vmin, float vmax) {
  value = std::clamp(value, vmin, vmax);
  float t = (value - vmin) / (vmax - vmin + 1e-9f);
  float start = (float)M_PI * 0.75f;    // 135deg
  float sweep = (float)M_PI * 1.5f;     // 270deg
  return start - t * sweep;
}

static void DrawGaugeBase(float cx, float cy, float r) {
  // background
  glColor4f(0.05f, 0.05f, 0.06f, 0.75f);
  DrawCircle(cx, cy, r, 64);

  // inner ring
  glColor4f(0.2f, 0.2f, 0.22f, 0.9f);
  DrawRing(cx, cy, r * 0.88f, r * 0.92f, 64);
}

static void DrawTicks(float cx, float cy, float r, int tick_count) {
  glColor4f(1.f, 1.f, 1.f, 0.9f);
  for (int i = 0; i <= tick_count; i++) {
    float t = (float)i / (float)tick_count;
    float a = (float)M_PI * 0.75f - t * (float)M_PI * 1.5f;
    float r1 = r * 0.78f;
    float r2 = r * 0.92f;

    float x1 = cx + r1 * std::cos(a);
    float y1 = cy + r1 * std::sin(a);
    float x2 = cx + r2 * std::cos(a);
    float y2 = cy + r2 * std::sin(a);

    glBegin(GL_LINES);
    glVertex2f(x1, y1);
    glVertex2f(x2, y2);
    glEnd();
  }
}

static void DrawSpeedometer(float cx, float cy, float r, double speed_kmh) {
  DrawGaugeBase(cx, cy, r);
  DrawTicks(cx, cy, r, 10);  // 0..200 step 20

  float a = GaugeAngle((float)speed_kmh, 0.f, 5.f);

  // needle
  glColor4f(1.0f, 0.25f, 0.25f, 1.0f);
  DrawNeedle(cx, cy, r * 0.75f, a, 3.0f);

  // center cap
  glColor4f(0.3f, 0.3f, 0.32f, 1.0f);
  DrawCircle(cx, cy, r * 0.06f, 24);
}

static void DrawTachometer(float cx, float cy, float r, double rpm) {
  DrawGaugeBase(cx, cy, r);
  DrawTicks(cx, cy, r, 8);  // 0..8000 step 1000

  // red zone ring (6000..8000)
  glColor4f(1.f, 0.f, 0.f, 0.18f);
  DrawRing(cx, cy, r * 0.86f, r * 0.92f, 64);

  float a = GaugeAngle((float)rpm, 0.f, 8000.f);

  // needle
  glColor4f(0.25f, 1.0f, 0.35f, 1.0f);
  DrawNeedle(cx, cy, r * 0.75f, a, 3.0f);

  // center cap
  glColor4f(0.3f, 0.3f, 0.32f, 1.0f);
  DrawCircle(cx, cy, r * 0.06f, 24);
}



void DashboardRenderer::Render(const DashboardData& data, const mjrRect& viewport, const mjrContext* ctx) {
  static int cnt = 0;
  if ((cnt++ % 120) == 0) {
    std::printf("[DashRender] speed=%.2f km/h rpm=%.0f\n", data.speed_kmh, data.rpm);
  }

  Begin2D(viewport);

  const float s = scale_;

  // Layout (bottom-left)
const float speed_cx = 160.f * s;
const float speed_cy = 160.f * s;   // ← 原来 160，升高到 300
const float radius   = 120.f * s;


  // Speedometer (0-200 km/h)
  DrawSpeedometer(speed_cx, speed_cy, radius, data.speed_kmh);

  // Tachometer above it
  DrawTachometer(speed_cx, speed_cy + 200.f * s, radius, data.rpm);

  // --- Removed: green/blue bars (Fuel/Temp) ---
  // float panel_x = (float)viewport.width - 280.f * s;
  // float panel_y =  70.f * s;
  // float bar_w = 220.f * s;
  // float bar_h = 16.f * s;
  //
  // // Fuel bar (green)
  // DrawBar(panel_x, panel_y + 60.f * s, bar_w, bar_h,
  //         (float)(data.fuel / 100.0), 0.2f, 1.0f, 0.25f);
  //
  // // Temp bar (blue/red)
  // float temp_ratio = (float)((data.temperature - 60.0) / 60.0);
  // if (temp_ratio > 0.8f) {
  //   DrawBar(panel_x, panel_y + 30.f * s, bar_w, bar_h,
  //           temp_ratio, 1.0f, 0.2f, 0.2f);
  // } else {
  //   DrawBar(panel_x, panel_y + 30.f * s, bar_w, bar_h,
  //           temp_ratio, 0.2f, 0.55f, 1.0f);
  // }

  End2D();

  // Optional: overlay text using MuJoCo (no font lib needed)
  if (ctx) {
    char line1[200];
    char line2[200];
    std::snprintf(line1, sizeof(line1), "Speed: %.1f km/h   RPM: %.0f", data.speed_kmh, data.rpm);
    std::snprintf(line2, sizeof(line2), "Pos: (%.2f, %.2f, %.2f)   Fuel: %.0f%%   Temp: %.1fC",
                  data.pos[0], data.pos[1], data.pos[2], data.fuel, data.temperature);

    // mjr_overlay draws in viewport coordinates
    mjr_overlay(mjFONT_NORMAL, mjGRID_TOPLEFT, viewport, line1, line2, ctx);
  }
}

